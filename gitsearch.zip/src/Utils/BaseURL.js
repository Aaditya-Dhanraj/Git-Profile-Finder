export const BASE_URL_GITHUB_API = "https://api.github.com";
