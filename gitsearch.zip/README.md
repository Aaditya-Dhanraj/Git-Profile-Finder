# Getting Started with Running and Testing the application

Prerequisite => node package manager (npm).

In order to run this project we have to follow these steps mentioned below : [Website](https://profilefinder.aadityadhanraj.com).

## Common Steps :

Step 1 : 

### `git clone https://github.com/Aaditya-Dhanraj/Git-Profile-Finder.git`

Step 2 : 
### `cd in the main directory`

Step 3 : 
### `npm install`


## For running the code on localhost RUN : 

### `npm start`


## For testing the code on localhost RUN : 

### `npm test`

Feel free to reach out to me if anything goes south.